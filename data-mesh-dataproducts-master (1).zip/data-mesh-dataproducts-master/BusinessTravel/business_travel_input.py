import pandas as pd

emp_personal_info_df = pd.read_csv("Employee_Information.csv")
emp_travel_info_df = pd.read_csv("Employee_Travel_Information.csv")
individually_travelled_emp_file_df = pd.read_csv("Individually_Travelled_Employee_File.csv")
travel_agency_file_df = pd.read_csv("Travel_Agency_File.csv")
emissions_lookup_for_car_df = pd.read_csv("Emission_Details_lookup_table_for_Car.csv")
emissions_lookup_road_travel_other_than_cars_df = pd.read_csv("Emission_Details_lookup_table_other_than_cars.csv")
emissions_lookup_rail_air_df = pd.read_csv("Emission_Details_lookup_table_rail_air.csv")
emissions_lookup_hotel_df = pd.read_csv("Emission_Details_lookup_table_hotel.csv")
