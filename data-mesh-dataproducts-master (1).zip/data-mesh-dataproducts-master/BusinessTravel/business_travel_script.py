import pandas as pd
from hamilton import function_modifiers
from functools import reduce

@function_modifiers.extract_columns(
    'EmployeeName',
    'TransportMode',
    'TravelledMonth_Year',
    'OrganizationName',
    'WorkRegion',
    'CO2eCalculationMethod',
    'EmissionCO2e',
    'Co2e Unit',
    'FuelType'
)
def business_travel(
        emp_personal_info_df_employee_name: pd.Series,
        emp_personal_info_df_employee_id: pd.Series,
        emp_personal_info_df_work_region: pd.Series,
        emp_personal_info_df_organisation_name: pd.Series,
        emp_personal_info_df_role: pd.Series,

        emp_travel_info_df_employee_name: pd.Series,
        emp_travel_info_df_employee_id: pd.Series,
        emp_travel_info_df_organisation_name: pd.Series,
        emp_travel_info_df_work_region: pd.Series,
        emp_travel_info_df_travelled_country: pd.Series,
        emp_travel_info_df_travelled_date: pd.Series,
        emp_travel_info_df_went_with_group: pd.Series,
        emp_travel_info_df_no_of_employees_in_group: pd.Series,

        individually_travelled_emp_file_df_employee_name: pd.Series,
        individually_travelled_emp_file_df_employee_id: pd.Series,
        individually_travelled_emp_file_df_organisation_name: pd.Series,
        individually_travelled_emp_file_df_work_region: pd.Series,
        individually_travelled_emp_file_df_travelled_country: pd.Series,
        individually_travelled_emp_file_df_travelled_date: pd.Series,
        individually_travelled_emp_file_df_employees_per_vehicle: pd.Series,
        individually_travelled_emp_file_df_transport_mode: pd.Series,
        individually_travelled_emp_file_df_total_nights_stayed: pd.Series,
        individually_travelled_emp_file_df_amount_spent_on_travel_mode: pd.Series,
        individually_travelled_emp_file_df_vehicle_manufacturer: pd.Series,
        individually_travelled_emp_file_df_vehicle_manufacturing_year: pd.Series,
        individually_travelled_emp_file_df_vehicle_subcategory: pd.Series,
        individually_travelled_emp_file_df_engine_capacity: pd.Series,
        individually_travelled_emp_file_df_version_or_class: pd.Series,
        individually_travelled_emp_file_df_fuel_type: pd.Series,
        individually_travelled_emp_file_df_distance_travelled_in_the_vehicle: pd.Series,
        individually_travelled_emp_file_df_amount_spent_on_fuel: pd.Series,
        individually_travelled_emp_file_df_fuel_consumed: pd.Series,
        individually_travelled_emp_file_df_fuel_price_per_l: pd.Series,
        individually_travelled_emp_file_df_electricity_consumed: pd.Series,

        travel_agency_file_df_employee_name: pd.Series,
        travel_agency_file_df_employee_id: pd.Series,
        travel_agency_file_df_organisation_name: pd.Series,
        travel_agency_file_df_work_region: pd.Series,
        travel_agency_file_df_travelled_country: pd.Series,
        travel_agency_file_df_travelled_date: pd.Series,
        travel_agency_file_df_employees_per_vehicle: pd.Series,
        travel_agency_file_df_transport_mode: pd.Series,
        travel_agency_file_df_total_nights_stayed: pd.Series,
        travel_agency_file_df_amount_spent_on_travel_mode: pd.Series,
        travel_agency_file_df_vehicle_manufacturer: pd.Series,
        travel_agency_file_df_vehicle_manufacturing_year: pd.Series,
        travel_agency_file_df_vehicle_subcategory: pd.Series,
        travel_agency_file_df_engine_capacity: pd.Series,
        travel_agency_file_df_version_or_class: pd.Series,
        travel_agency_file_df_fuel_type: pd.Series,
        travel_agency_file_df_distance_travelled_in_the_vehicle: pd.Series,
        travel_agency_file_df_amount_spent_on_fuel: pd.Series,
        travel_agency_file_df_fuel_consumed: pd.Series,
        travel_agency_file_df_fuel_price_per_l: pd.Series,
        travel_agency_file_df_electricity_consumed: pd.Series,
        travel_agency_file_df_agency_name: pd.Series,

        emissions_lookup_for_car_df_country: pd.Series,
        emissions_lookup_for_car_df_vfn: pd.Series,
        emissions_lookup_for_car_df_mp: pd.Series,
        emissions_lookup_for_car_df_mh: pd.Series,
        emissions_lookup_for_car_df_man: pd.series,
        emissions_lookup_for_car_df_mms: pd.series,
        emissions_lookup_for_car_df_t: pd.series,
        emissions_lookup_for_car_df_va: pd.series,
        emissions_lookup_for_car_df_version_or_class: pd.series,
        emissions_lookup_for_car_df_vehicle_manufacturer: pd.series,
        emissions_lookup_for_car_df_vehicle_subcategory: pd.series,
        emissions_lookup_for_car_df_ct: pd.series,
        emissions_lookup_for_car_df_cr: pd.series,
        emissions_lookup_for_car_df_r: pd.Series,
        emissions_lookup_for_car_df_m_kg: pd.Series,
        emissions_lookup_for_car_df_enedc_g_per_km: pd.series,
        emissions_lookup_for_car_df_emission_g_per_km: pd.series,
        emissions_lookup_for_car_df_w_mm: pd.series,
        emissions_lookup_for_car_df_at1_mm: pd.series,
        emissions_lookup_for_car_df_at2_mm: pd.series,
        emissions_lookup_for_car_df_ft: pd.series,
        emissions_lookup_for_car_df_fuel_mode: pd.series,
        emissions_lookup_for_car_df_engine_capacity: pd.series,
        emissions_lookup_for_car_df_ep_kw: pd.series,
        emissions_lookup_for_car_df_z_wh_per_km: pd.series,
        emissions_lookup_for_car_df_it: pd.series,
        emissions_lookup_for_car_df_ernedc_g_per_km: pd.series,
        emissions_lookup_for_car_df_erwltp_g_per_km: pd.series,
        emissions_lookup_for_car_df_de: pd.series,
        emissions_lookup_for_car_df_vf: pd.series,
        emissions_lookup_for_car_df_status: pd.series,
        emissions_lookup_for_car_df_vehicle_manufacturing_year: pd.series,
        emissions_lookup_for_car_df_electric_range_km: pd.series,
        emissions_lookup_for_car_df_ef_for_fuels_kgco2e_per_l: pd.series,
        emissions_lookup_for_car_df_cyl: pd.series,
        emissions_lookup_for_car_df_engine_l: pd.series,
        emissions_lookup_for_car_df_fuel_tank_l: pd.series,
        emissions_lookup_for_car_df_consumed_l_per_100km: pd.series,
        emissions_lookup_for_car_df_range_km: pd.series,
        emissions_lookup_for_car_df_eeio_ef: pd.series,

        emissions_lookup_road_travel_other_than_cars_df_travelled_country: pd.Series,
        emissions_lookup_road_travel_other_than_cars_df_methodology_reference: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_transport_mode: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_vehicle_subcategory: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_fuel_type: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_ef_for_fuels_kgco2e_per_l: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_number_of_passengers: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_vehicle_model_year: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_journey_type: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_applicable_from: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_applicable_to: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_emission_kg_per_km: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_emissions_factor_co2: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_emissions_factor_ch4: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_emissions_factor_n2o: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_biofuel_emissions_factor_kgco2unit: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_out_of_scope_emissions_factor_kgco2eunit: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_eeio_ef: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_supply_chain_emissions_factor_kgco2eunit: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_production_sc_emissions_factor_kgco2eunit: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_biofuel_sc_emissions_factor_kgco2eunit: pd.series,
        emissions_lookup_road_travel_other_than_cars_df_emissions_factor_source: pd.series,

        emissions_lookup_rail_air_df_methodology_reference: pd.series,
        emissions_lookup_rail_air_df_transport_mode: pd.series,
        emissions_lookup_rail_air_df_vehicle_subcategory: pd.series,
        emissions_lookup_rail_air_df_version_or_class: pd.series,
        emissions_lookup_rail_air_df_ef_for_fuels_kgco2e_per_l: pd.series,
        emissions_lookup_rail_air_df_applicable_from: pd.series,
        emissions_lookup_rail_air_df_applicable_to: pd.series,
        emissions_lookup_rail_air_df_uplift_factor: pd.series,
        emissions_lookup_rail_air_df_emission_kg_per_km: pd.series,
        emissions_lookup_rail_air_df_emissions_factor_kgco2pkm: pd.series,
        emissions_lookup_rail_air_df_emissions_factor_kgch4pkm: pd.series,
        emissions_lookup_rail_air_df_emissions_factor_kgn2opkm: pd.series,
        emissions_lookup_rail_air_df_eeio_ef: pd.series,
        emissions_lookup_rail_air_df_supply_chain_emissions_factor_kgco2epkm: pd.series,
        emissions_lookup_rail_air_df_emissions_factor_source: pd.series,

        emissions_lookup_hotel_df_transport_mode: pd.series,
        emissions_lookup_hotel_df_travelled_country: pd.series,
        emissions_lookup_hotel_df_applicable_from: pd.series,
        emissions_lookup_hotel_df_travelled_date: pd.series,
        emissions_lookup_hotel_df_units: pd.series,
        emissions_lookup_hotel_df_emissions_factor_kgco2e: pd.series

):
    emp_personal_info_dataframe = \
        emp_personal_info_df_employee_name.to_frame('employee_name') \
        .join(emp_personal_info_df_employee_id.to_frame('employee_id')) \
        .join(emp_personal_info_df_work_region.to_frame('work_region')) \
        .join(emp_personal_info_df_organisation_name.to_frame('organisation_name')) \
        .join(emp_personal_info_df_role.to_frame('role'))

    emp_travel_info_dataframe = \
        emp_travel_info_df_employee_name.to_frame('employee_name') \
        .join(emp_travel_info_df_employee_id.to_frame('employee_id')) \
        .join(emp_travel_info_df_organisation_name.to_frame('organisation_name')) \
        .join(emp_travel_info_df_work_region.to_frame('work_region')) \
        .join(emp_travel_info_df_travelled_country.to_frame('travelled_country')) \
        .join(emp_travel_info_df_travelled_date.to_frame('travelled_date')) \
        .join(emp_travel_info_df_went_with_group.to_frame('went_with_group')) \
        .join(emp_travel_info_df_no_of_employees_in_group.to_frame('no_of_employees_in_group'))

    individually_travelled_emp_file_dataframe = \
        individually_travelled_emp_file_df_employee_name.to_frame('employee_name') \
        .join(individually_travelled_emp_file_df_employee_id.to_frame('employee_id')) \
        .join(individually_travelled_emp_file_df_organisation_name.to_frame('organisation_name')) \
        .join(individually_travelled_emp_file_df_work_region.to_frame('work_region')) \
        .join(individually_travelled_emp_file_df_travelled_country.to_frame('travelled_country')) \
        .join(individually_travelled_emp_file_df_travelled_date.to_frame('travelled_date')) \
        .join(individually_travelled_emp_file_df_employees_per_vehicle.to_frame('employees_per_vehicle')) \
        .join(individually_travelled_emp_file_df_transport_mode.to_frame('transport_mode')) \
        .join(individually_travelled_emp_file_df_total_nights_stayed.to_frame('total_nights_stayed')) \
        .join(individually_travelled_emp_file_df_amount_spent_on_travel_mode.to_frame('amount_spent_on_travel_mode')) \
        .join(individually_travelled_emp_file_df_vehicle_manufacturer.to_frame('vehicle_manufacturer')) \
        .join(individually_travelled_emp_file_df_vehicle_manufacturing_year.to_frame('vehicle_manufacturing_year')) \
        .join(individually_travelled_emp_file_df_vehicle_subcategory.to_frame('vehicle_subcategory')) \
        .join(individually_travelled_emp_file_df_engine_capacity.to_frame('engine_capacity')) \
        .join(individually_travelled_emp_file_df_version_or_class.to_frame('version_or_class')) \
        .join(individually_travelled_emp_file_df_fuel_type.to_frame('fuel_type')) \
        .join(individually_travelled_emp_file_df_distance_travelled_in_the_vehicle
              .to_frame('distance_travelled_in_the_vehicle')) \
        .join(individually_travelled_emp_file_df_amount_spent_on_fuel.to_frame('amount_spent_on_fuel')) \
        .join(individually_travelled_emp_file_df_fuel_consumed.to_frame('fuel_consumed')) \
        .join(individually_travelled_emp_file_df_fuel_price_per_l.to_frame('fuel_price_per_l')) \
        .join(individually_travelled_emp_file_df_electricity_consumed.to_frame('electricity_consumed'))

    travel_agency_file_dataframe = \
        travel_agency_file_df_employee_name.to_frame('employee_name') \
        .join(travel_agency_file_df_employee_id.to_frame('employee_id')) \
        .join(travel_agency_file_df_organisation_name.to_frame('organisation_name')) \
        .join(travel_agency_file_df_work_region.to_frame('work_region')) \
        .join(travel_agency_file_df_travelled_country.to_frame('travelled_country')) \
        .join(travel_agency_file_df_travelled_date.to_frame('travelled_date')) \
        .join(travel_agency_file_df_employees_per_vehicle.to_frame('employees_per_vehicle')) \
        .join(travel_agency_file_df_transport_mode.to_frame('transport_mode')) \
        .join(travel_agency_file_df_total_nights_stayed.to_frame('total_nights_stayed')) \
        .join(travel_agency_file_df_amount_spent_on_travel_mode.to_frame('amount_spent_on_travel_mode')) \
        .join(travel_agency_file_df_vehicle_manufacturer.to_frame('vehicle_manufacturer')) \
        .join(travel_agency_file_df_vehicle_manufacturing_year.to_frame('vehicle_manufacturing_year')) \
        .join(travel_agency_file_df_vehicle_subcategory.to_frame('vehicle_subcategory')) \
        .join(travel_agency_file_df_engine_capacity.to_frame('engine_capacity')) \
        .join(travel_agency_file_df_version_or_class.to_frame('version_or_class')) \
        .join(travel_agency_file_df_fuel_type.to_frame('fuel_type')) \
        .join(travel_agency_file_df_distance_travelled_in_the_vehicle.to_frame('distance_travelled_in_the_vehicle')) \
        .join(travel_agency_file_df_amount_spent_on_fuel.to_frame('amount_spent_on_fuel')) \
        .join(travel_agency_file_df_fuel_consumed.to_frame('fuel_consumed')) \
        .join(travel_agency_file_df_fuel_price_per_l.to_frame('fuel_price_per_l')) \
        .join(travel_agency_file_df_electricity_consumed.to_frame('electricity_consumed')) \
        .join(travel_agency_file_df_agency_name.to_frame('agency_name'))

    emissions_lookup_for_car_dataframe = \
        emissions_lookup_for_car_df_country.to_frame('country') \
        .join(emissions_lookup_for_car_df_vfn.to_frame('vfn')) \
        .join(emissions_lookup_for_car_df_mp.to_frame('mp')) \
        .join(emissions_lookup_for_car_df_mh.to_frame('mh')) \
        .join(emissions_lookup_for_car_df_man.to_frame('man')) \
        .join(emissions_lookup_for_car_df_mms.to_frame('mms')) \
        .join(emissions_lookup_for_car_df_t.to_frame('t')) \
        .join(emissions_lookup_for_car_df_va.to_frame('va')) \
        .join(emissions_lookup_for_car_df_version_or_class.to_frame('version_or_class')) \
        .join(emissions_lookup_for_car_df_vehicle_manufacturer.to_frame('vehicle_manufacturer')) \
        .join(emissions_lookup_for_car_df_vehicle_subcategory.to_frame('vehicle_subcategory')) \
        .join(emissions_lookup_for_car_df_ct.to_frame('ct')) \
        .join(emissions_lookup_for_car_df_cr.to_frame('cr')) \
        .join(emissions_lookup_for_car_df_r.to_frame('r')) \
        .join(emissions_lookup_for_car_df_m_kg.to_frame('m_kg')) \
        .join(emissions_lookup_for_car_df_enedc_g_per_km.to_frame('enedc_g_per_km')) \
        .join(emissions_lookup_for_car_df_emission_g_per_km.to_frame('emission_g_per_km')) \
        .join(emissions_lookup_for_car_df_w_mm.to_frame('w_mm')) \
        .join(emissions_lookup_for_car_df_at1_mm.to_frame('at1_mm')) \
        .join(emissions_lookup_for_car_df_at2_mm.to_frame('at2_mm')) \
        .join(emissions_lookup_for_car_df_ft.to_frame('ft')) \
        .join(emissions_lookup_for_car_df_fuel_mode.to_frame('fuel_mode')) \
        .join(emissions_lookup_for_car_df_engine_capacity.to_frame('engine_capacity')) \
        .join(emissions_lookup_for_car_df_ep_kw.to_frame('ep_kw')) \
        .join(emissions_lookup_for_car_df_z_wh_per_km.to_frame('z_wh_per_km')) \
        .join(emissions_lookup_for_car_df_it.to_frame('it')) \
        .join(emissions_lookup_for_car_df_ernedc_g_per_km.to_frame('ernedc_g_per_km')) \
        .join(emissions_lookup_for_car_df_erwltp_g_per_km.to_frame('erwltp_g_per_km')) \
        .join(emissions_lookup_for_car_df_de.to_frame('de')) \
        .join(emissions_lookup_for_car_df_vf.to_frame('vf')) \
        .join(emissions_lookup_for_car_df_status.to_frame('status')) \
        .join(emissions_lookup_for_car_df_vehicle_manufacturing_year.to_frame('vehicle_manufacturing_year')) \
        .join(emissions_lookup_for_car_df_electric_range_km.to_frame('electric_range_km')) \
        .join(emissions_lookup_for_car_df_ef_for_fuels_kgco2e_per_l.to_frame('ef_for_fuels_kgco2e_per_l')) \
        .join(emissions_lookup_for_car_df_cyl.to_frame('cyl')) \
        .join(emissions_lookup_for_car_df_engine_l.to_frame('engine_l')) \
        .join(emissions_lookup_for_car_df_fuel_tank_l.to_frame('fuel_tank_l')) \
        .join(emissions_lookup_for_car_df_consumed_l_per_100km.to_frame('consumed_l_per_100km')) \
        .join(emissions_lookup_for_car_df_range_km.to_frame('range_km')) \
        .join(emissions_lookup_for_car_df_eeio_ef.to_frame('eeio_ef'))

    emissions_lookup_road_travel_other_than_cars_dataframe = \
        emissions_lookup_road_travel_other_than_cars_df_travelled_country.to_frame('travelled_country') \
        .join(emissions_lookup_road_travel_other_than_cars_df_methodology_reference.to_frame('methodology_reference')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_transport_mode.to_frame('transport_mode')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_vehicle_subcategory.to_frame('vehicle_subcategory')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_fuel_type.to_frame('fuel_type')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_ef_for_fuels_kgco2e_per_l
              .to_frame('ef_for_fuels_kgco2e_per_l')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_number_of_passengers.to_frame('number_of_passengers')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_vehicle_model_year.to_frame('vehicle_model_year')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_journey_type.to_frame('journey_type')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_applicable_from.to_frame('applicable_from')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_applicable_to.to_frame('applicable_to')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_emission_kg_per_km.to_frame('emission_kg_per_km')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_emissions_factor_co2.to_frame('emissions_factor_co2')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_emissions_factor_ch4.to_frame('emissions_factor_ch4')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_emissions_factor_n2o.to_frame('emissions_factor_n2o')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_biofuel_emissions_factor_kgco2unit
              .to_frame('biofuel_emissions_factor_kgco2unit')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_out_of_scope_emissions_factor_kgco2eunit
              .to_frame('out_of_scope_emissions_factor_kgco2eunit')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_eeio_ef.to_frame('eeio_ef')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_supply_chain_emissions_factor_kgco2eunit
              .to_frame('supply_chain_emissions_factor_kgco2eunit')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_production_sc_emissions_factor_kgco2eunit
              .to_frame('production_sc_emissions_factor_kgco2eunit')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_biofuel_sc_emissions_factor_kgco2eunit
              .to_frame('biofuel_sc_emissions_factor_kgco2eunit')) \
        .join(emissions_lookup_road_travel_other_than_cars_df_emissions_factor_source
              .to_frame('emissions_factor_source'))

    emissions_lookup_rail_air_dataframe = \
        emissions_lookup_rail_air_df_methodology_reference.to_frame('methodology_reference') \
        .join(emissions_lookup_rail_air_df_transport_mode.to_frame('transport_mode')) \
        .join(emissions_lookup_rail_air_df_vehicle_subcategory.to_frame('vehicle_subcategory')) \
        .join(emissions_lookup_rail_air_df_version_or_class.to_frame('version_or_class')) \
        .join(emissions_lookup_rail_air_df_ef_for_fuels_kgco2e_per_l.to_frame('ef_for_fuels_kgco2e_per_l')) \
        .join(emissions_lookup_rail_air_df_applicable_from.to_frame('applicable_from')) \
        .join(emissions_lookup_rail_air_df_applicable_to.to_frame('applicable_to')) \
        .join(emissions_lookup_rail_air_df_uplift_factor.to_frame('uplift_factor')) \
        .join(emissions_lookup_rail_air_df_emission_kg_per_km.to_frame('emission_kg_per_km')) \
        .join(emissions_lookup_rail_air_df_emissions_factor_kgco2pkm.to_frame('emissions_factor_kgco2pkm')) \
        .join(emissions_lookup_rail_air_df_emissions_factor_kgch4pkm.to_frame('emissions_factor_kgch4pkm')) \
        .join(emissions_lookup_rail_air_df_emissions_factor_kgn2opkm.to_frame('emissions_factor_kgn2opkm')) \
        .join(emissions_lookup_rail_air_df_eeio_ef.to_frame('eeio_ef')) \
        .join(emissions_lookup_rail_air_df_supply_chain_emissions_factor_kgco2epkm
              .to_frame('supply_chain_emissions_factor_kgco2epkm')) \
        .join(emissions_lookup_rail_air_df_emissions_factor_source.to_frame('emissions_factor_source'))

    emissions_lookup_hotel_dataframe = \
        emissions_lookup_hotel_df_transport_mode.to_frame('transport_mode') \
        .join(emissions_lookup_hotel_df_travelled_country.to_frame('travelled_country')) \
        .join(emissions_lookup_hotel_df_applicable_from.to_frame('applicable_from')) \
        .join(emissions_lookup_hotel_df_travelled_date.to_frame('travelled_date')) \
        .join(emissions_lookup_hotel_df_units.to_frame('units')) \
        .join(emissions_lookup_hotel_df_emissions_factor_kgco2e.to_frame('emissions_factor_kgco2e'))

    emp_travel_info_dataframe['no_of_employees_in_group'] = emp_travel_info_dataframe['no_of_employees_in_group']\
        .fillna(1)
    emp_travel_info_dataframe = emp_travel_info_dataframe.fillna('Not Admissible')

    individually_travelled_emp_file_dataframe['amount_spent_on_fuel'] = \
        individually_travelled_emp_file_dataframe['amount_spent_on_fuel'].fillna(0)
    individually_travelled_emp_file_dataframe['fuel_consumed'] = \
        individually_travelled_emp_file_dataframe['fuel_consumed'].fillna(0)
    individually_travelled_emp_file_dataframe['electricity_consumed'] = \
        individually_travelled_emp_file_dataframe['electricity_consumed'].fillna(0)
    individually_travelled_emp_file_dataframe['employees_per_vehicle'] = \
        individually_travelled_emp_file_dataframe['employees_per_vehicle'].fillna(1)
    individually_travelled_emp_file_dataframe['engine_capacity'] = \
        individually_travelled_emp_file_dataframe['engine_capacity'].fillna(0)
    individually_travelled_emp_file_dataframe['fuel_price_per_l'] = \
        individually_travelled_emp_file_dataframe['fuel_price_per_l'].fillna(0)
    individually_travelled_emp_file_dataframe['amount_spent_on_travel_mode'] = \
        individually_travelled_emp_file_dataframe['amount_spent_on_travel_mode'].fillna(0)
    individually_travelled_emp_file_dataframe['distance_travelled_in_the_vehicle'] = \
        individually_travelled_emp_file_dataframe['distance_travelled_in_the_vehicle'].fillna(0)
    individually_travelled_emp_file_dataframe['total_nights_stayed'] = \
        individually_travelled_emp_file_dataframe['total_nights_stayed'].fillna(0)
    individually_travelled_emp_file_dataframe = individually_travelled_emp_file_dataframe.fillna('Not Admissible')

    travel_agency_file_dataframe['amount_spent_on_fuel'] = travel_agency_file_dataframe['amount_spent_on_fuel']\
        .fillna(0)
    travel_agency_file_dataframe['fuel_consumed'] = travel_agency_file_dataframe['fuel_consumed'].fillna(0)
    travel_agency_file_dataframe['electricity_consumed'] = travel_agency_file_dataframe['electricity_consumed']\
        .fillna(0)
    travel_agency_file_dataframe['employees_per_vehicle'] = travel_agency_file_dataframe['employees_per_vehicle']\
        .fillna(1)
    travel_agency_file_dataframe['engine_capacity'] = travel_agency_file_dataframe['engine_capacity'].fillna(0)
    travel_agency_file_dataframe['fuel_price_per_l'] = travel_agency_file_dataframe['fuel_price_per_l'].fillna(0)
    travel_agency_file_dataframe['amount_spent_on_travel_mode'] = \
        travel_agency_file_dataframe['amount_spent_on_travel_mode'].fillna(0)
    travel_agency_file_dataframe['distance_travelled_in_the_vehicle'] = \
        travel_agency_file_dataframe['distance_travelled_in_the_vehicle'].fillna(0)
    travel_agency_file_dataframe['total_nights_stayed'] = travel_agency_file_dataframe['total_nights_stayed'].fillna(0)
    travel_agency_file_dataframe = travel_agency_file_dataframe.fillna('Not Admissible')

    emissions_lookup_for_car_dataframe['engine_capacity'] = emissions_lookup_for_car_dataframe['engine_capacity']\
        .fillna(0)
    emissions_lookup_for_car_dataframe['ef_for_fuels_kgco2e_per_l'] = \
        emissions_lookup_for_car_dataframe['ef_for_fuels_kgco2e_per_l'].fillna(0)
    emissions_lookup_for_car_dataframe['consumed_l_per_100km'] = \
        emissions_lookup_for_car_dataframe['consumed_l_per_100km'].fillna(0)

    emissions_lookup_road_travel_other_than_cars_dataframe['ef_for_fuels_kgco2e_per_l'] = \
        emissions_lookup_road_travel_other_than_cars_dataframe['ef_for_fuels_kgco2e_per_l'].fillna(0)

    emissions_lookup_rail_air_dataframe['vehicle_subcategory'] = \
        emissions_lookup_rail_air_dataframe['vehicle_subcategory'].fillna('Not Admissible')
    emissions_lookup_rail_air_dataframe['VersionOrClass'] = emissions_lookup_rail_air_dataframe['VersionOrClass']\
        .fillna('Not Admissible')
    emissions_lookup_rail_air_dataframe['Ef for fuels kgCO2e/L'] = \
        emissions_lookup_rail_air_dataframe['Ef for fuels kgCO2e/L'].fillna(0)

    input_dfs = [emp_personal_info_dataframe, emp_travel_info_dataframe, travel_agency_file_dataframe,
                 individually_travelled_emp_file_dataframe]
    combined_input_dfs = reduce(lambda df_left, df_right: pd.merge(df_left, df_right,
                                                                   left_index=False, right_index=False,
                                                                   how='outer'), input_dfs)

    combined_input_dfs = combined_input_dfs.sort_values(by=['employee_id', 'organisation_name', 'work_region'])
    combined_input_dfs['engine_capacity'].astype('float')

    combined_input_with_emission_df = pd.merge(combined_input_dfs, emissions_lookup_for_car_dataframe,
                                               on=['vehicle_manufacturer', 'vehicle_subcategory', 'engine_capacity',
                                                   'version_or_class'], how='left')
    final_combined_input_with_emission_df = combined_input_with_emission_df[
        ['employee_name', 'employee_id', 'work_region', 'organisation_name', 'role', 'travelled_country',
         'travelled_date', 'went_with_group', 'no_of_employees_in_group', 'employees_per_vehicle', 'transport_mode',
         'total_nights_stayed', 'ef_for_fuels_kgco2e_per_l', 'amount_spent_on_travel_mode', 'vehicle_manufacturer',
         'vehicle_subcategory', 'engine_capacity', 'version_or_class', 'fuel_type', 'distance_travelled_in_the_vehicle',
         'fuel_price_per_l', 'amount_spent_on_fuel', 'fuel_consumed', 'electricity_consumed', 'consumed_l_per_100km',
         'agency_name', 'emission_g_per_km', 'eeio_ef']].copy()
    final_combined_input_with_emission_df.insert(22, "emission_kg_per_km", True)
    final_combined_input_with_emission_df['emission_kg_per_km'] = final_combined_input_with_emission_df[
                                                                   'emission_g_per_km'] / 1000

    final_emission_df = pd.merge(final_combined_input_with_emission_df,
                                 emissions_lookup_road_travel_other_than_cars_dataframe,
                                 on=['travelled_country', 'transport_mode'], how='left')

    final_emission_df['ef_for_fuels_kgco2e_per_l_x'] = final_emission_df['ef_for_fuels_kgco2e_per_l_x'].fillna(0)
    final_emission_df['ef_for_fuels_kgco2e_per_l_y'] = final_emission_df['ef_for_fuels_kgco2e_per_l_y'].fillna(0)
    final_emission_df['ef_for_fuels_kgco2e_per_l'] = \
        final_emission_df['ef_for_fuels_kgco2e_per_l_x'] + final_emission_df['ef_for_fuels_kgco2e_per_l_y']
    final_emission_df['vehicle_subcategory'] = (final_emission_df['vehicle_subcategory_x'].fillna('')).astype(str)
    final_emission_df['fuel_type'] = (final_emission_df['fuel_type_x'].fillna('')).astype(str)
    final_emission_df['emission_kg_per_km'] = (final_emission_df['emission_kg_per_km_x'].fillna('')).astype(str) + (
        final_emission_df['emission_kg_per_km_y'].fillna('')).astype(str)
    final_emission_df['eeio_ef'] = (final_emission_df['eeio_ef_x'].fillna('')).astype(str) + (
        final_emission_df['eeio_ef_y'].fillna('')).astype(str)
    final_emission_df_1 = final_emission_df[
        ['employee_name', 'employee_id', 'work_region', 'organisation_name', 'role', 'travelled_country',
         'travelled_date', 'went_with_group', 'no_of_employees_in_group', 'employees_per_vehicle',
         'transport_mode', 'total_nights_stayed', 'ef_for_fuels_kgco2e_per_l', 'amount_spent_on_travel_mode',
         'vehicle_manufacturer', 'vehicle_subcategory', 'engine_capacity', 'version_or_class', 'fuel_type',
         'distance_travelled_in_the_vehicle', 'fuel_price_per_l', 'amount_spent_on_fuel', 'fuel_consumed',
         'electricity_consumed', 'agency_name', 'consumed_l_per_100km', 'emission_kg_per_km', 'eeio_ef']].copy()

    fin_emi_df = pd.merge(final_emission_df_1, emissions_lookup_rail_air_dataframe,
                          on=['transport_mode', 'vehicle_subcategory', 'version_or_class'], how='left')
    fin_emi_df['emission_kg_per_km'] = (fin_emi_df['emission_kg_per_km_x'].fillna('')).astype(str) + (
        fin_emi_df['emission_kg_per_km_y'].fillna('')).astype(str)
    fin_emi_df['eeio_ef'] = (fin_emi_df['eeio_ef_x'].fillna('')).astype(str) + (
        fin_emi_df['eeio_ef_y'].fillna('')).astype(str)
    fin_emi_df['ef_for_fuels_kgco2e_per_l_x'] = fin_emi_df['ef_for_fuels_kgco2e_per_l_x'].fillna(0)
    fin_emi_df['ef_for_fuels_kgco2e_per_l_y'] = fin_emi_df['ef_for_fuels_kgco2e_per_l_y'].fillna(0)
    fin_emi_df['ef_for_fuels_kgco2e_per_l'] = \
        fin_emi_df['ef_for_fuels_kgco2e_per_l_x'] + fin_emi_df['ef_for_fuels_kgco2e_per_l_y']
    fin_emi_df_1 = fin_emi_df[
        ['employee_name', 'employee_id', 'work_region', 'organisation_name', 'role', 'travelled_country',
         'travelled_date', 'went_with_group', 'no_of_employees_in_group', 'employees_per_vehicle', 'transport_mode',
         'total_nights_stayed', 'ef_for_fuels_kgco2e_per_l', 'amount_spent_on_travel_mode', 'vehicle_manufacturer',
         'vehicle_subcategory', 'engine_capacity', 'version_or_class', 'fuel_type', 'distance_travelled_in_the_vehicle',
         'fuel_price_per_l', 'amount_spent_on_fuel', 'fuel_consumed', 'electricity_consumed', 'agency_name',
         'consumed_l_per_100km', 'emission_kg_per_km', 'eeio_ef']].copy()
    fin_emi_df_1['no_of_employees_in_group'] = fin_emi_df_1['no_of_employees_in_group'].fillna(1)

    emp_emission_info_df1 = fin_emi_df_1
    emp_emission_info_df1['amount_spent_on_travel_mode'] = \
        emp_emission_info_df1['amount_spent_on_travel_mode'].fillna(0)
    emp_emission_info_df1['emission_kg_per_km'] = emp_emission_info_df1['emission_kg_per_km'].replace('', 0)
    emp_emission_info_df1['emission_kg_per_km'] = emp_emission_info_df1['emission_kg_per_km'].astype(float)
    emp_emission_info_df1['eeio_ef'] = emp_emission_info_df1['eeio_ef'].replace('', 0)
    emp_emission_info_df1['eeio_ef'] = emp_emission_info_df1['eeio_ef'].astype(float)

    emp_emission_info_df2 = pd.merge(emp_emission_info_df1, emissions_lookup_hotel_dataframe,
                                     on=['transport_mode', 'travelled_country'], how='left')
    emp_emission_info_df2['travelled_date'] = emp_emission_info_df2['travelled_date_x']

    emp_emission_info_df = emp_emission_info_df2[
        ['employee_name', 'employee_id', 'work_region', 'organisation_name', 'role',
         'travelled_country', 'travelled_date', 'went_with_group',
         'no_of_employees_in_group', 'employees_per_vehicle', 'transport_mode',
         'total_nights_stayed', 'ef_for_fuels_kgco2e_per_l',
         'amount_spent_on_travel_mode', 'vehicle_manufacturer',
         'vehicle_subcategory', 'engine_capacity', 'version_or_class', 'fuel_type',
         'distance_travelled_in_the_vehicle', 'fuel_price_per_l',
         'amount_spent_on_fuel', 'fuel_consumed', 'electricity_consumed',
         'agency_name', 'consumed_l_per_100km', 'emission_kg_per_km', 'eeio_ef',
         'emissions_factor_kgco2e']]

    Inter_df = pd.DataFrame()

    Inter_df['EmployeeName'] = emp_emission_info_df['employee_name']
    Inter_df['EmployeeID'] = emp_emission_info_df['employee_id']
    Inter_df['OrganisationName'] = emp_emission_info_df['organisation_name']
    Inter_df['WorkRegion'] = emp_emission_info_df['work_region']
    Inter_df['TravelledMonth_Year'] = pd.to_datetime(emp_emission_info_df['travelled_date'], format='%Y%m%d')
    Inter_df['TravelledMonth_Year'] = Inter_df['TravelledMonth_Year'].apply(lambda i: i.strftime('%B-%Y'))
    Inter_df['TravelledCountry'] = emp_emission_info_df['travelled_country']
    Inter_df['TransportMode'] = emp_emission_info_df['transport_mode']
    Inter_df['Fuel Consumed'] = emp_emission_info_df['fuel_consumed']
    Inter_df['Ef for fuels kgCO2e/L'] = emp_emission_info_df['ef_for_fuels_kgco2e_per_l']
    Inter_df['consumed L/km'] = emp_emission_info_df['consumed_l_per_100km'] / 100
    Inter_df['Fuel price per L'] = emp_emission_info_df['fuel_price_per_l'].astype(float)
    Inter_df['AmountSpentOnFuelIn$'] = emp_emission_info_df['amount_spent_on_fuel'].astype(float)
    Inter_df['TotalNightsStayed'] = emp_emission_info_df['total_nights_stayed'].fillna(0)
    Inter_df['Emissions Factor kgCO2e'] = emp_emission_info_df['emissions_factor_kgco2e'].fillna(0)
    temp = pd.DataFrame()

    Inter_df['Fuel Consumed'] = Inter_df['Fuel Consumed'].fillna(0)

    Inter_df.loc[Inter_df['Fuel Consumed'] == 0, 'Fuel Consumed'] = (
                emp_emission_info_df['consumed_l_per_100km'] / 100).mul(
        emp_emission_info_df['distance_travelled_in_the_vehicle'].fillna(0))
    Inter_df['Fuel Consumed'] = Inter_df['Fuel Consumed'].fillna(0)
    Inter_df.loc[Inter_df['Fuel Consumed'] == 0, 'Fuel Consumed'] = Inter_df['AmountSpentOnFuelIn$'].div(
        Inter_df['Fuel price per L'].fillna(1))
    Inter_df['Fuel Consumed'] = Inter_df['Fuel Consumed'].fillna(0)

    temp['TransportMode'] = Inter_df['TransportMode']
    ser_tm = Inter_df['TransportMode']
    temp['Fuel based emission'] = Inter_df['Fuel Consumed'].mul(Inter_df['Ef for fuels kgCO2e/L'].fillna(0))
    temp['Fuel based emission'] = temp['Fuel based emission'].fillna(0)
    temp.loc[temp['Fuel based emission'] == 0, 'Distance based emission'] = (
        emp_emission_info_df['no_of_employees_in_group']
        .mul(emp_emission_info_df['distance_travelled_in_the_vehicle']))\
        .mul(emp_emission_info_df['emission_kg_per_km'])
    temp.loc[temp['Distance based emission'] == 0, 'spend based emission'] = emp_emission_info_df[
        'amount_spent_on_travel_mode'].fillna(0).mul(emp_emission_info_df['eeio_ef'].fillna(0))

    temp['Distance based emission'] = temp['Distance based emission'].fillna(0)
    temp['spend based emission'] = temp['spend based emission'].fillna(0)

    temp.loc[temp['Fuel based emission'] != 0, 'CO2eCalculationMethod'] = "Fuel-based Method"
    temp.loc[temp['Distance based emission'] != 0, 'CO2eCalculationMethod'] = "Distance-based Method"
    temp.loc[temp['spend based emission'] != 0, 'CO2eCalculationMethod'] = "Spend-based Method"

    tmp = pd.DataFrame()

    tmp['EmissionCO2e'] = temp['Fuel based emission'] + temp['Distance based emission'] + temp['spend based emission']
    for x in ser_tm:
        if x == "Hotel":
            tmp.loc[tmp['EmissionCO2e'] == 0, 'EmissionCO2e'] = Inter_df['TotalNightsStayed'].mul(
                Inter_df['Emissions Factor kgCO2e'])

    Inter_df['EmissionCO2e'] = tmp['EmissionCO2e'].fillna(0)
    Inter_df['Co2e Unit'] = "kg"
    Inter_df['FuelType'] = emp_emission_info_df['FuelType']
    Inter_df['CO2eCalculationMethod'] = temp['CO2eCalculationMethod'].fillna('Hotel-Stayed Method')
    Inter_df['Scope'] = 3
    Inter_df['Fuel Consumed'] = emp_emission_info_df['Fuel Consumed']
    Inter_df['TransportMode'] = temp['TransportMode']
    Inter_df.to_csv('out.csv')

    fin_df = Inter_df.groupby(['EmployeeName', 'TransportMode', 'TravelledMonth_Year', 'OrganisationName', 'WorkRegion',
                               'CO2eCalculationMethod'], as_index=False).agg({'EmissionCO2e': 'sum'})
    fin_df['Co2e Unit'] = Inter_df['Co2e Unit']
    fin_df['FuelType'] = Inter_df['FuelType']
    fin_df.to_csv('final_out.csv')
    print("Done")
